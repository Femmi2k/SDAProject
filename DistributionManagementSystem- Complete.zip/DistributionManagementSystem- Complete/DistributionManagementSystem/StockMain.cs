﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DistributionManagementSystem
{
    public partial class StockMain : Form
    {

        public StockMain()
        {
            InitializeComponent();
        }

        private void productsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Products prod = new Products();
            prod.MdiParent = this;//snaps the form to parent form
            prod.Show();
        }
        bool shutdown = true;
        private void StockMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (shutdown)
            {
                DialogResult confirm = MessageBox.Show("Are you sure you want to exit?", "Confirmation", MessageBoxButtons.YesNo);
                if (confirm == DialogResult.Yes)
                {
                    shutdown = false;
                    Application.Exit();
                }
                else { e.Cancel = true; } 
            }
        }

        private void stockToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Stock stock = new Stock();
            stock.MdiParent = this;
            stock.StartPosition = FormStartPosition.CenterScreen;
            stock.Show();
        }

        private void productListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReportForms.ProductReport prod = new ReportForms.ProductReport();
            prod.MdiParent = this;
            prod.StartPosition = FormStartPosition.CenterScreen;
            prod.Show();
        }

        private void stockListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReportForms.StockReport stck = new ReportForms.StockReport();
            stck.MdiParent = this;
            stck.StartPosition = FormStartPosition.CenterScreen;
            stck.Show();
        }
    }
}
