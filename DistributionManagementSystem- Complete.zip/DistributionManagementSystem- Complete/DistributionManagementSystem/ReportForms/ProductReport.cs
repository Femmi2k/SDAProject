﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.Reporting.WinForms;
using CrystalDecisions.CrystalReports.Engine;

namespace DistributionManagementSystem.ReportForms
{
    public partial class ProductReport : Form
    {
        ReportDocument cypt = new ReportDocument();
        public ProductReport()
        {
            InitializeComponent();
        }

        private void ProductReport_Load(object sender, EventArgs e)
        {
            cypt.Load(@"C:\Users\Fehmaan Shahid\Desktop\Stuff\Uni stuff\Bahria\Semester 4\SDA\Project\DistributionManagementSystem\DistributionManagementSystem\Reports\Product.rpt");
            SqlConnection con = new SqlConnection("Data Source=ASUS\\SQLEXPRESS;Initial Catalog=SDAProject;Integrated Security=True");
            con.Open();
            DataSet dst = new DataSet();
            SqlDataAdapter sda = new SqlDataAdapter("Select * From [Products]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            cypt.SetDataSource(dt);
            crystalReportViewer1.ReportSource = cypt;


        }
    }
}
