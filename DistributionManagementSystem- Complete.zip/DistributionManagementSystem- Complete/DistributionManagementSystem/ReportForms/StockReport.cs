﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CrystalDecisions.ReportSource;
using CrystalDecisions.CrystalReports.Engine;
using System.Data.SqlClient;

namespace DistributionManagementSystem.ReportForms
{
    public partial class StockReport : Form
    {
        ReportDocument cypt = new ReportDocument();
        public StockReport()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cypt.Load(@"C:\Users\Fehmaan Shahid\Desktop\Stuff\Uni stuff\Bahria\Semester 4\SDA\Project\DistributionManagementSystem\DistributionManagementSystem\Reports\Stock.rpt");
            SqlConnection con = new SqlConnection("Data Source=ASUS\\SQLEXPRESS;Initial Catalog=SDAProject;Integrated Security=True");
            con.Open();
            DataSet dst = new DataSet();
            SqlDataAdapter sda = new SqlDataAdapter("Select * From [Stock] where Cast(TransDate as Date) between '" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "' and '" +dateTimePicker2.Value.ToString("MM/dd/yyyy")+ "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dst,"Stock");
            cypt.SetParameterValue("@FromDate", dateTimePicker1.Value.ToString("dd/MM/yyyy"));
            cypt.SetParameterValue("@ToDate", dateTimePicker2.Value.ToString("dd/MM/yyyy"));
            crystalReportViewer1.ReportSource = cypt;
        }
    }
}
