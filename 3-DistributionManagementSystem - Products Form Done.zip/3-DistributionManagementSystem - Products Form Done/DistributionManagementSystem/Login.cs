﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DistributionManagementSystem
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=ASUS\\SQLEXPRESS;Initial Catalog=SDAProject;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter(@"SELECT*FROM [dbo].[Logins] where Username = '"+ usr.Text+"' and Passwords= '"+pw.Text+"'",con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                StockMain mm = new StockMain();
                this.Hide();
                mm.Show();
            }
            else {
                MessageBox.Show("Invalid Login","Re-Enter data", MessageBoxButtons.OK, MessageBoxIcon.Error);
                usr.Text = "";
                pw.Text = "";
            }
        }
    }
}
