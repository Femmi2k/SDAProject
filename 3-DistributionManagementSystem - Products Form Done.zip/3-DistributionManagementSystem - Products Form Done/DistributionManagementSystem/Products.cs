﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DistributionManagementSystem
{
    public partial class Products : Form
    {
        public Products()
        {
            InitializeComponent();
            DataLoad();
        }

        private void Products_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
            
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (Validate())
            {
                SqlConnection con = new SqlConnection("Data Source=ASUS\\SQLEXPRESS;Initial Catalog=SDAProject;Integrated Security=True");
                //insertion to database
                con.Open();
                bool stat = false;
                if (comboBox1.SelectedIndex == 0)
                {
                    stat = true;
                }
                else
                {
                    stat = false;
                }
                //for updatation if record already exists

                var sqlQuery = "";
                if (ifprodexist(con, textBox1.Text))
                {
                    sqlQuery = @"UPDATE [Products]  SET [Name] = '" + textBox2.Text + "',[Prodtatus] = '" + stat + "' WHERE [ProdCode] = '" + textBox1.Text + "'";
                }
                else
                {
                    sqlQuery = @"INSERT INTO [dbo].[Products]([ProdCode],[Name],[Prodtatus])VALUES
            ('" + textBox1.Text + "','" + textBox2.Text + "','" + stat + "')";
                }
                //Insertion code
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.ExecuteNonQuery();
                con.Close();

                DataLoad();
                reset(); 
            }
        }
        //updatation code again
        private bool ifprodexist(SqlConnection con, string prodcode)
        {
            SqlDataAdapter sda = new SqlDataAdapter("Select 1 From [dbo].[Products] WHERE [ProdCode] ='" + prodcode + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                return true;
            }
            else { return false; }
        }
        //data to grid code
        public void DataLoad()
        {
            SqlConnection con = new SqlConnection("Data Source=ASUS\\SQLEXPRESS;Initial Catalog=SDAProject;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("Select * From [dbo].[Products]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.Rows.Clear();
            foreach (DataRow item in dt.Rows)
            {
                int n = dataGridView1.Rows.Add();
                dataGridView1.Rows[n].Cells[0].Value = item["ProdCode"].ToString();
                dataGridView1.Rows[n].Cells[1].Value = item["Name"].ToString();
                if ((bool)item["Prodtatus"])
                {
                    dataGridView1.Rows[n].Cells[2].Value = "Active";
                }
                else
                {
                    dataGridView1.Rows[n].Cells[2].Value = "Inactive";
                }
            }
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            button1.Text = "Update";
            textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            if (dataGridView1.SelectedRows[0].Cells[2].Value.ToString()== "Active")
            {
                comboBox1.SelectedIndex = 0;
            }
            else
            {
                comboBox1.SelectedIndex = 1;
            }
        }
        //record deletion
        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult cnfrm = MessageBox.Show("Are you sure you want to delete", "Confirmation", MessageBoxButtons.YesNo);
            if (cnfrm == DialogResult.Yes)
            {
                if (Validate())
                {
                    SqlConnection con = new SqlConnection("Data Source=ASUS\\SQLEXPRESS;Initial Catalog=SDAProject;Integrated Security=True");
                    var sqlQuery = "";
                    if (ifprodexist(con, textBox1.Text))
                    {
                        con.Open();
                        sqlQuery = @"DELETE FROM [Products] WHERE [ProdCode] = '" + textBox1.Text + "'";
                        SqlCommand cmd = new SqlCommand(sqlQuery, con);
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                    else
                    {
                        MessageBox.Show("Record does not exist");
                    }

                    DataLoad();
                    reset();
                }
            }
        }
        private void reset()
        {
            textBox1.Clear();
            textBox2.Clear();
            comboBox1.SelectedIndex = -1;
            button1.Text = "Add";
            textBox1.Focus();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            reset();
        }

        private bool Validate()
        {
            bool result = false;
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                errorProvider1.Clear();
                errorProvider1.SetError(textBox1, "Product Code Required");
            }
            else if (string.IsNullOrEmpty(textBox1.Text))
            {
                errorProvider1.Clear();
                errorProvider1.SetError(textBox1, "Product Name Required");
            }
            else if (comboBox1.SelectedIndex == -1)
            {
                errorProvider1.Clear();
                errorProvider1.SetError(comboBox1, "Set status");
            }
            else {
                result = true;
            }
            return result;
        }
    }
}
