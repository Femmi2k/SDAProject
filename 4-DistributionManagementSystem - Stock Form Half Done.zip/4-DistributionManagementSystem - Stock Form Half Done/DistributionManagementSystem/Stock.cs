﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DistributionManagementSystem
{
    public partial class Stock : Form
    {
        public Stock()
        {
            InitializeComponent();
            textBox1.Focus();
            DataLoad();
        }
        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) & (Keys)e.KeyChar != Keys.Back & e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            reset();
        }
        public void reset()
        {
            dateTimePicker1.Value = DateTime.Now;
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            button1.Text = "Add";
            dateTimePicker1.Focus();
        }

        private bool validate()
        {
            bool result = false;
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                errorProvider1.Clear();
                errorProvider1.SetError(textBox1, "Product Code Required");
            }
            else if (string.IsNullOrEmpty(textBox2.Text))
            {
                errorProvider1.Clear();
                errorProvider1.SetError(textBox2, "Product Name Required");
            }
            else if (string.IsNullOrEmpty(textBox3.Text))
            {
                errorProvider1.Clear();
                errorProvider1.SetError(textBox3, "Quantity Required");
            }
            else
            {
                errorProvider1.Clear();
                result = true;
            }
            return result;
        }

        private bool ifprodexist(SqlConnection con, string prodcode)
        {
            SqlDataAdapter sda = new SqlDataAdapter("Select 1 From [dbo].[Stock] WHERE [ProdCode] ='" + prodcode + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                return true;
            }
            else { return false; }
        }


        public void DataLoad()
        {
            SqlConnection con = new SqlConnection("Data Source=ASUS\\SQLEXPRESS;Initial Catalog=SDAProject;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("Select * From [dbo].[Stock]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.Rows.Clear();
            foreach (DataRow item in dt.Rows)
            {
                int n = dataGridView1.Rows.Add();
                dataGridView1.Rows[n].Cells[0].Value = n + 1;
                dataGridView1.Rows[n].Cells[1].Value = item["ProdCode"].ToString();
                dataGridView1.Rows[n].Cells[2].Value = item["ProdName"].ToString();
                dataGridView1.Rows[n].Cells[3].Value = float.Parse(item["Quantity"].ToString());
                dataGridView1.Rows[n].Cells[4].Value = Convert.ToDateTime(item["TransDate"].ToString()).ToString("dd/MM/yyyy");
                if (dataGridView1.Rows.Count > 0)
                {
                    label5.Text = "Total Products: " + dataGridView1.Rows.Count.ToString();
                    float total = 0;
                    for (int i = 0; i < dataGridView1.Rows.Count; ++i)
                    {
                        total += float.Parse(dataGridView1.Rows[i].Cells[3].Value.ToString());
                        label6.Text = "Total Quantity: " + total.ToString();
                    }
                }
                else { label5.Text = "Total Products: 0";
                label6.Text = "Total Quantity: 0";
                }
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (Validate())
            {
                SqlConnection con = new SqlConnection("Data Source=ASUS\\SQLEXPRESS;Initial Catalog=SDAProject;Integrated Security=True");
                //insertion to database
                con.Open();

                //for updatation if record already exists

                var sqlQuery = "";
                if (ifprodexist(con, textBox1.Text))
                {
                    sqlQuery = @"UPDATE [Stock]  SET [ProdName] = '" + textBox2.Text + "',[Quantity] = '" + textBox3.Text + "' WHERE [ProdCode] = '" + textBox1.Text + "'";
                }
                else
                {
                    sqlQuery = @"INSERT INTO [dbo].[Stock]([ProdCode],[ProdName],[TransDate],[Quantity])
                    VALUES('" + textBox1.Text + "','" + textBox2.Text + "','" + dateTimePicker1.Value.ToString("MM/dd/yyyy") + "','" + textBox3.Text + "')";
                }
                //Insertion code
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.ExecuteNonQuery();
                con.Close();
                DataLoad();
                reset();
            }
           
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            button1.Text = "Update";
            textBox1.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            textBox2.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
            textBox3.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
            dateTimePicker1.Text = DateTime.Parse(dataGridView1.SelectedRows[0].Cells[4].Value.ToString()).ToString("dd/MM/yyyy");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult cnfrm = MessageBox.Show("Are you sure you want to delete", "Confirmation", MessageBoxButtons.YesNo);
            if (cnfrm == DialogResult.Yes)
            {
                if (Validate())
                {
                    SqlConnection con = new SqlConnection("Data Source=ASUS\\SQLEXPRESS;Initial Catalog=SDAProject;Integrated Security=True");
                    var sqlQuery = "";
                    if (ifprodexist(con, textBox1.Text))
                    {
                        con.Open();
                        sqlQuery = @"DELETE FROM [Stock] WHERE [ProdCode] = '" + textBox1.Text + "'";
                        SqlCommand cmd = new SqlCommand(sqlQuery, con);
                        cmd.ExecuteNonQuery();
                        con.Close();
                    }
                    else
                    {
                        MessageBox.Show("Record does not exist");
                    }

                    DataLoad();
                    reset();
                }
            }
        }
    }
}