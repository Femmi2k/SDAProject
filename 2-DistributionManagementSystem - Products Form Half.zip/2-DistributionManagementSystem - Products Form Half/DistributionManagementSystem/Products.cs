﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DistributionManagementSystem
{
    public partial class Products : Form
    {
        public Products()
        {
            InitializeComponent();
            DataLoad();
        }

        private void Products_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=ASUS\\SQLEXPRESS;Initial Catalog=SDAProject;Integrated Security=True");
            //insertion to database
            con.Open();
            bool stat = false;
            if (comboBox1.SelectedIndex == 0)
            {
                stat = true;
            }
            else
            {
                stat = false;
            }
            //for updatation if record already exists

            var sqlQuery = "";
            if (ifprodexist(con,textBox1.Text))
            {
                sqlQuery = @"UPDATE [Products]  SET [Name] = '" + textBox2.Text + "',[Prodtatus] = '" + stat + "' WHERE [ProdCode] = '" + textBox1.Text + "'";
            }
            else
            {
            sqlQuery = @"INSERT INTO [dbo].[Products]([ProdCode],[Name],[Prodtatus])VALUES
            ('"+textBox1.Text+"','"+textBox2.Text+"','"+stat+"')";
            }
            //Insertion code
            SqlCommand cmd = new SqlCommand(sqlQuery,con);
            cmd.ExecuteNonQuery();
            con.Close();
            
            DataLoad();
        }
        //updatation code again
        private bool ifprodexist(SqlConnection con, string prodcode)
        {
            SqlDataAdapter sda = new SqlDataAdapter("Select 1 From [dbo].[Products] WHERE [ProdCode] ='" + prodcode + "'", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                return true;
            }
            else { return false; }
        }
        public void DataLoad()
        {
            SqlConnection con = new SqlConnection("Data Source=ASUS\\SQLEXPRESS;Initial Catalog=SDAProject;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("Select * From [dbo].[Products]", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.Rows.Clear();
            foreach (DataRow item in dt.Rows)
            {
                int n = dataGridView1.Rows.Add();
                dataGridView1.Rows[n].Cells[0].Value = item["ProdCode"].ToString();
                dataGridView1.Rows[n].Cells[1].Value = item["Name"].ToString();
                if ((bool)item["Prodtatus"])
                {
                    dataGridView1.Rows[n].Cells[2].Value = "Active";
                }
                else
                {
                    dataGridView1.Rows[n].Cells[2].Value = "Inactive";
                }

            }
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            textBox1.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            if (dataGridView1.SelectedRows[0].Cells[2].Value.ToString()== "Active")
            {
                comboBox1.SelectedIndex = 0;
            }
            else
            {
                comboBox1.SelectedIndex = 1;
            }
        }
        //record deletion
        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=ASUS\\SQLEXPRESS;Initial Catalog=SDAProject;Integrated Security=True");
            var sqlQuery = "";
            if (ifprodexist(con, textBox1.Text))
            {
                con.Open();
                sqlQuery = @"DELETE FROM [Products] WHERE [ProdCode] = '" + textBox1.Text + "'";
                SqlCommand cmd = new SqlCommand(sqlQuery, con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
            else
            {
                MessageBox.Show("Record does not exist");
            }
            //Insertion code
           

            DataLoad();
        }
    }
}
